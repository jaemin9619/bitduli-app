import { firebaseConfig } from "./firebase-config.js";

const enabled = Boolean(firebaseConfig && firebaseConfig.projectId);
const cdn = "https://www.gstatic.com/firebasejs/11.10.0";

let firebase = null;

async function loadFirebase() {
  if (!enabled) return null;
  if (firebase) return firebase;

  const [{ initializeApp }, authMod, firestoreMod, functionsMod] = await Promise.all([
    import(`${cdn}/firebase-app.js`),
    import(`${cdn}/firebase-auth.js`),
    import(`${cdn}/firebase-firestore.js`),
    import(`${cdn}/firebase-functions.js`)
  ]);

  const app = initializeApp(firebaseConfig);
  const auth = authMod.getAuth(app);
  const db = firestoreMod.getFirestore(app);
  const functions = functionsMod.getFunctions(app, "asia-northeast3");

  firebase = {
    app,
    auth,
    db,
    functions,
    ...authMod,
    ...firestoreMod,
    ...functionsMod
  };

  return firebase;
}

function assertUser(user) {
  if (!user?.uid) {
    throw new Error("Firebase user is required.");
  }
}

function diaryPath(uid, date) {
  return ["users", uid, "diaries", date];
}

function todoPath(uid, id) {
  return ["users", uid, "todos", id];
}

export const LineMeCloud = {
  isEnabled: () => enabled,

  async signInWithGoogle() {
    const fb = await loadFirebase();
    if (!fb) return null;

    const provider = new fb.GoogleAuthProvider();
    provider.addScope("email");
    provider.addScope("profile");
    const result = await fb.signInWithPopup(fb.auth, provider);
    const user = result.user;

    await fb.setDoc(
      fb.doc(fb.db, "users", user.uid),
      {
        displayName: user.displayName || "",
        email: user.email || "",
        photoURL: user.photoURL || "",
        onboardingComplete: false,
        lastLoginAt: fb.serverTimestamp(),
        updatedAt: fb.serverTimestamp(),
        createdAt: fb.serverTimestamp()
      },
      { merge: true }
    );

    return user;
  },

  async currentUser() {
    const fb = await loadFirebase();
    return fb?.auth.currentUser || null;
  },

  async saveCharacter(user, character) {
    const fb = await loadFirebase();
    if (!fb) return;
    assertUser(user);

    await fb.setDoc(
      fb.doc(fb.db, "users", user.uid, "characters", "default"),
      {
        ...character,
        updatedAt: fb.serverTimestamp()
      },
      { merge: true }
    );
  },

  async saveDiaryEntry(user, date, entry) {
    const fb = await loadFirebase();
    if (!fb) return;
    assertUser(user);

    await fb.setDoc(
      fb.doc(fb.db, ...diaryPath(user.uid, date)),
      {
        ownerId: user.uid,
        date,
        title: entry.title,
        weather: entry.weather,
        mood: entry.mood,
        body: entry.body,
        summary: entry.summary,
        tags: entry.tags || [],
        imageUrl: entry.imageUrl || "",
        imageStoragePath: entry.imageStoragePath || "",
        visibility: entry.shared ? "friends" : "private",
        likesCount: entry.likes || 0,
        commentsCount: entry.comments || 0,
        updatedAt: fb.serverTimestamp(),
        createdAt: fb.serverTimestamp()
      },
      { merge: true }
    );

    await Promise.all(
      (entry.todos || []).map((todo, index) =>
        fb.setDoc(
          fb.doc(fb.db, ...todoPath(user.uid, `${date}-${index + 1}`)),
          {
            diaryDate: date,
            date,
            title: todo.title,
            completed: Boolean(todo.done),
            googleCalendarLinked: Boolean(todo.calendar),
            googleCalendarEventId: todo.googleCalendarEventId || "",
            updatedAt: fb.serverTimestamp(),
            createdAt: fb.serverTimestamp()
          },
          { merge: true }
        )
      )
    );
  },

  async listMonthEntries(user, yearMonth) {
    const fb = await loadFirebase();
    if (!fb) return {};
    assertUser(user);

    const start = `${yearMonth}-01`;
    const endMonth = new Date(`${start}T00:00:00`);
    endMonth.setMonth(endMonth.getMonth() + 1);
    const end = endMonth.toISOString().slice(0, 10);

    const queryRef = fb.query(
      fb.collection(fb.db, "users", user.uid, "diaries"),
      fb.where("date", ">=", start),
      fb.where("date", "<", end),
      fb.orderBy("date", "asc")
    );
    const snapshot = await fb.getDocs(queryRef);
    return Object.fromEntries(snapshot.docs.map((docSnap) => [docSnap.id, docSnap.data()]));
  },

  async requestLineArtGeneration(user, date, entry, character) {
    const fb = await loadFirebase();
    if (!fb) return null;
    assertUser(user);

    const callable = fb.httpsCallable(fb.functions, "generateDiaryLineArt");
    return callable({
      date,
      entry,
      character
    });
  }
};

window.LineMeCloud = LineMeCloud;
