import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { getStorage } from "firebase-admin/storage";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { setGlobalOptions } from "firebase-functions/v2";
import { GoogleAuth } from "google-auth-library";

initializeApp();
setGlobalOptions({ region: "asia-northeast3", maxInstances: 10 });

const db = getFirestore();
const auth = new GoogleAuth({
  scopes: ["https://www.googleapis.com/auth/cloud-platform"]
});

function requireAuth(request) {
  if (!request.auth?.uid) {
    throw new HttpsError("unauthenticated", "Google sign-in is required.");
  }
  return request.auth.uid;
}

function validateEntry(entry) {
  if (!entry || typeof entry.body !== "string" || entry.body.trim().length < 2) {
    throw new HttpsError("invalid-argument", "Diary body is required.");
  }
}

function buildPrompt(entry, character) {
  const characterText = [
    character?.hair,
    character?.outfit,
    character?.accessory,
    character?.color ? `point color ${character.color}` : ""
  ]
    .filter(Boolean)
    .join(", ");

  return [
    "Create a clean Korean diary line-art illustration.",
    "Style: black hand-drawn line art, white paper background, warm and minimal, childlike picture diary layout.",
    "Use one subtle point color only for the user's character.",
    `Character: ${characterText || "simple friendly student character"}.`,
    `Diary title: ${entry.title || "오늘의 그림일기"}.`,
    `Diary text: ${entry.body}.`,
    `Detected mood: ${entry.mood || "보통"}.`,
    `Tags: ${(entry.tags || []).join(", ")}.`,
    "Composition: one representative scene at the top, Korean diary grid text area at the bottom.",
    "Avoid photorealism, avoid complex backgrounds, avoid logos."
  ].join("\n");
}

async function saveGenerationJob(uid, date, payload) {
  const ref = db.collection("users").doc(uid).collection("generationJobs").doc(`${date}-${Date.now()}`);
  await ref.set({
    ownerId: uid,
    date,
    status: "queued",
    ...payload,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp()
  });
  return ref;
}

async function generateImageWithVertex(prompt) {
  const project = process.env.GCLOUD_PROJECT || process.env.GCP_PROJECT;
  const location = process.env.VERTEX_LOCATION || "us-central1";
  const model = process.env.VERTEX_IMAGE_MODEL || "imagen-4.0-generate-preview-06-06";

  if (!project) {
    throw new Error("Missing GCP project id.");
  }

  const client = await auth.getClient();
  const token = await client.getAccessToken();
  const url = `https://${location}-aiplatform.googleapis.com/v1/projects/${project}/locations/${location}/publishers/google/models/${model}:predict`;

  const response = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token.token || token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      instances: [{ prompt }],
      parameters: {
        sampleCount: 1,
        aspectRatio: "3:4",
        safetyFilterLevel: "block_some",
        personGeneration: "allow_adult"
      }
    })
  });

  if (!response.ok) {
    const message = await response.text();
    throw new Error(`Vertex AI request failed: ${response.status} ${message}`);
  }

  const data = await response.json();
  const prediction = data.predictions?.[0] || {};
  const bytes = prediction.bytesBase64Encoded || prediction.image?.bytesBase64Encoded;

  if (!bytes) {
    return {
      bytes: null,
      raw: data
    };
  }

  return {
    bytes,
    mimeType: prediction.mimeType || "image/png",
    raw: data
  };
}

export const generateDiaryLineArt = onCall(async (request) => {
  const uid = requireAuth(request);
  const { date, entry, character } = request.data || {};
  validateEntry(entry);

  const diaryDate = typeof date === "string" ? date : new Date().toISOString().slice(0, 10);
  const prompt = buildPrompt(entry, character);
  const jobRef = await saveGenerationJob(uid, diaryDate, { prompt });

  try {
    const generated = await generateImageWithVertex(prompt);

    if (!generated.bytes) {
      await jobRef.update({
        status: "prompt_ready",
        modelResponseText: JSON.stringify(generated.raw || {}),
        updatedAt: FieldValue.serverTimestamp()
      });

      return {
        jobId: jobRef.id,
        status: "prompt_ready",
        prompt
      };
    }

    const buffer = Buffer.from(generated.bytes, "base64");
    const bucket = getStorage().bucket();
    const storagePath = `users/${uid}/diaries/${diaryDate}-${jobRef.id}.png`;
    const file = bucket.file(storagePath);

    await file.save(buffer, {
      metadata: {
        contentType: generated.mimeType || "image/png",
        metadata: {
          ownerId: uid,
          date: diaryDate,
          source: "vertex-ai"
        }
      }
    });

    await db.collection("users").doc(uid).collection("diaries").doc(diaryDate).set(
      {
        imageStoragePath: storagePath,
        generationJobId: jobRef.id,
        updatedAt: FieldValue.serverTimestamp()
      },
      { merge: true }
    );

    await jobRef.update({
      status: "completed",
      imageStoragePath: storagePath,
      updatedAt: FieldValue.serverTimestamp()
    });

    return {
      jobId: jobRef.id,
      status: "completed",
      imageStoragePath: storagePath
    };
  } catch (error) {
    await jobRef.update({
      status: "failed",
      errorMessage: error.message || String(error),
      updatedAt: FieldValue.serverTimestamp()
    });
    throw new HttpsError("internal", "Vertex AI generation failed.", {
      jobId: jobRef.id
    });
  }
});
