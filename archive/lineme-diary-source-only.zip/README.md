# LineMe Diary PWA

AI 캐릭터와 함께하는 라인 아트 그림일기 서비스 PWA 프로토타입입니다.

## 실행

```powershell
cd C:\Users\명재민\Documents\26빅데이터\lineme-diary
python -m http.server 4173
```

브라우저에서 `http://localhost:4173/`을 엽니다.

## 포함 기능

- Figma 기반 모바일 앱 셸
- 시작 화면, Google 로그인 목업, 사용자/캐릭터 설정
- 월간 캘린더와 날짜별 그림일기 조회
- 일기 작성, 감정/태그/투두 추출 목업, AI 생성 결과 화면
- 친구 피드, 월간 그림책, 설정 화면
- `manifest.webmanifest`와 `sw.js`를 포함한 PWA 구성
- `localStorage` 기반 데이터 저장
- Firebase 설정이 들어오면 Firestore에 캐릭터, 일기, 투두 데이터를 저장
- Vertex AI 이미지 생성은 Cloud Functions 서버 함수로 분리

## 참고

Firebase Authentication, Firestore, Cloud Storage, Vertex AI, Google Calendar API는 제안서 기준의 실제 연동 대상입니다. 현재 UI는 Firebase 설정이 없으면 목업으로 동작하고, `firebase-config.js`에 Firebase Web App 설정을 넣으면 Firestore 저장 경로를 사용합니다.

## GCP/Firebase 구성 파일

- `firebase.json`: Hosting, Firestore, Storage, Functions 배포 설정
- `firestore.rules`: 사용자별 데이터 접근 규칙
- `firestore.indexes.json`: 캘린더/피드 조회용 복합 인덱스
- `storage.rules`: 일기 이미지/캐릭터 이미지 저장 규칙
- `firebase-client.js`: 브라우저 Firebase SDK 어댑터
- `firebase-config.js`: Firebase Web App 설정 입력 위치
- `functions/index.js`: Vertex AI 이미지 생성 callable function
- `docs/database-schema.md`: Firestore 컬렉션/필드 설계
- `docs/gcp-firebase-setup.md`: GCP와 Firebase 적용 순서
