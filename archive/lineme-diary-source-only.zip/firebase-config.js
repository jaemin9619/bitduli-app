export const firebaseConfig = {
  apiKey: "AIzaSyDOfeWqghWRzASJjgcTW68NDT5mC3ZKx8w",
  authDomain: "bigdata-50693.firebaseapp.com",
  projectId: "bigdata-50693",
  storageBucket: "bigdata-50693.firebasestorage.app",
  messagingSenderId: "576174998758",
  appId: "1:576174998758:web:311063faf40bf88d4e2727",
  measurementId: "G-K05RNEEN2V"
};
