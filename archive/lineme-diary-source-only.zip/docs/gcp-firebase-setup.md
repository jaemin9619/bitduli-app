# GCP and Firebase Setup

## 1. Create or Select a GCP Project

```powershell
gcloud config set project YOUR_GCP_PROJECT_ID
```

Enable billing for the project in the Google Cloud Console.

## 2. Enable APIs

```powershell
gcloud services enable firebase.googleapis.com
gcloud services enable firestore.googleapis.com
gcloud services enable firebasestorage.googleapis.com
gcloud services enable cloudfunctions.googleapis.com
gcloud services enable run.googleapis.com
gcloud services enable artifactregistry.googleapis.com
gcloud services enable aiplatform.googleapis.com
gcloud services enable cloudbuild.googleapis.com
```

Enable later when Calendar integration starts:

```powershell
gcloud services enable calendar-json.googleapis.com
```

## 3. Create Firebase App

1. Open Firebase Console.
2. Add Firebase to the GCP project.
3. Create a Web app.
4. Copy the web app config.
5. Replace `firebaseConfig = null` in `firebase-config.js`.

## 4. Configure Project Alias

Copy `.firebaserc.example` to `.firebaserc`, then replace `YOUR_GCP_PROJECT_ID`.

```powershell
copy .firebaserc.example .firebaserc
```

## 5. Create Firestore

Create Cloud Firestore in Native mode. Recommended location for Korea-adjacent latency:

- `asia-northeast3` if available for your chosen Firebase resources
- otherwise `asia-northeast1`

Deploy rules and indexes:

```powershell
firebase deploy --only firestore
```

## 6. Create Cloud Storage Bucket

Create the default Firebase Storage bucket, then deploy rules:

```powershell
firebase deploy --only storage
```

## 7. Deploy Hosting

```powershell
firebase deploy --only hosting
```

## 8. Deploy Vertex AI Function

Install function dependencies:

```powershell
cd functions
npm install
cd ..
```

Optional: set model and region.

```powershell
firebase functions:config:set vertex.location="us-central1"
```

For the current function, environment variables are read as:

- `VERTEX_LOCATION`, default `us-central1`
- `VERTEX_IMAGE_MODEL`, default `imagen-4.0-generate-preview-06-06`

Set them in the Cloud Functions runtime if your project uses another Imagen model.

Deploy:

```powershell
firebase deploy --only functions
```

## 9. IAM

The Cloud Functions service account needs:

- `Vertex AI User`
- `Cloud Datastore User`
- `Storage Object Admin`

The browser app does not need Vertex AI credentials.

## 10. Calendar Integration Later

Add OAuth consent screen scopes only when implementing real Calendar sync:

- `https://www.googleapis.com/auth/calendar.events`
- `https://www.googleapis.com/auth/calendar.readonly`

Store event IDs in `users/{uid}/todos/{todoId}.googleCalendarEventId`.
