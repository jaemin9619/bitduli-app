# LineMe Diary Firestore Schema

## Service Choice

Use Cloud Firestore in Native mode.

Reasons:

- Diary, character, todo, friend, comment data are document-oriented.
- Calendar UI needs date-range queries.
- Friend feed needs real-time updates.
- Firebase Authentication integrates directly with Firestore security rules.
- Cloud Functions can write trusted AI generation results without exposing Vertex AI credentials to the browser.

## Collections

```text
users/{uid}
users/{uid}/characters/default
users/{uid}/diaries/{yyyy-mm-dd}
users/{uid}/todos/{todoId}
users/{uid}/friends/{friendUid}
users/{uid}/monthlyBooks/{yyyy-mm}
users/{uid}/generationJobs/{jobId}
publicFeed/{feedId}
publicFeed/{feedId}/comments/{commentId}
publicFeed/{feedId}/reactions/{uid}
```

## `users/{uid}`

```json
{
  "displayName": "명재민",
  "email": "cloudpro3Z@iceu.kr",
  "photoURL": "",
  "onboardingComplete": true,
  "createdAt": "serverTimestamp",
  "updatedAt": "serverTimestamp",
  "lastLoginAt": "serverTimestamp"
}
```

## `users/{uid}/characters/default`

```json
{
  "hair": "짧은 머리",
  "outfit": "후드티",
  "accessory": "백팩",
  "color": "#FFE068",
  "promptMetadata": {
    "style": "clean Korean diary line art",
    "consistencySeed": "optional-user-seed"
  },
  "updatedAt": "serverTimestamp"
}
```

## `users/{uid}/diaries/{yyyy-mm-dd}`

```json
{
  "ownerId": "firebase-auth-uid",
  "date": "2026-07-08",
  "title": "카페에서 보낸 하루",
  "weather": "맑음",
  "mood": "즐거움",
  "body": "오늘 친구들과 카페에서 발표 준비를 했다...",
  "summary": "친구들과 발표 자료를 만들며 피곤함과 즐거움을 함께 느낀 하루.",
  "tags": ["카페", "친구", "발표", "즐거움"],
  "imageUrl": "",
  "imageStoragePath": "users/{uid}/diaries/2026-07-08-job.png",
  "generationJobId": "2026-07-08-...",
  "visibility": "private",
  "likesCount": 0,
  "commentsCount": 0,
  "createdAt": "serverTimestamp",
  "updatedAt": "serverTimestamp"
}
```

`visibility` values:

- `private`: owner only
- `friends`: owner and accepted friends
- `public`: reserved for later public publishing

## `users/{uid}/todos/{todoId}`

```json
{
  "diaryDate": "2026-07-08",
  "date": "2026-07-09",
  "title": "내일 리허설 일정 등록",
  "completed": false,
  "googleCalendarLinked": true,
  "googleCalendarEventId": "",
  "createdAt": "serverTimestamp",
  "updatedAt": "serverTimestamp"
}
```

## `users/{uid}/friends/{friendUid}`

```json
{
  "displayName": "친구 1",
  "email": "friend@example.com",
  "status": "accepted",
  "createdAt": "serverTimestamp",
  "updatedAt": "serverTimestamp"
}
```

`status` values:

- `pending`
- `accepted`
- `blocked`

## `users/{uid}/generationJobs/{jobId}`

```json
{
  "ownerId": "firebase-auth-uid",
  "date": "2026-07-08",
  "status": "queued",
  "prompt": "Create a clean Korean diary line-art illustration...",
  "imageStoragePath": "",
  "errorMessage": "",
  "createdAt": "serverTimestamp",
  "updatedAt": "serverTimestamp"
}
```

`status` values:

- `queued`
- `prompt_ready`
- `completed`
- `failed`

## `users/{uid}/monthlyBooks/{yyyy-mm}`

```json
{
  "month": "2026-07",
  "entryDates": ["2026-07-08", "2026-07-10"],
  "keywords": ["친구", "발표", "산책"],
  "moodSummary": {
    "즐거움": 1,
    "차분함": 1
  },
  "pdfStoragePath": "",
  "createdAt": "serverTimestamp",
  "updatedAt": "serverTimestamp"
}
```

## `publicFeed/{feedId}`

Use only when a diary is shared.

```json
{
  "ownerId": "firebase-auth-uid",
  "ownerName": "명재민",
  "diaryDate": "2026-07-08",
  "diaryRefPath": "users/{uid}/diaries/2026-07-08",
  "title": "카페에서 보낸 하루",
  "summary": "친구들과 발표 자료를 만들며...",
  "imageStoragePath": "users/{uid}/diaries/2026-07-08-job.png",
  "visibility": "friends",
  "likesCount": 0,
  "commentsCount": 0,
  "createdAt": "serverTimestamp",
  "updatedAt": "serverTimestamp"
}
```

## Required Indexes

Already defined in `firestore.indexes.json`:

- `diaries`: `ownerId ASC`, `date DESC`
- `diaries`: `visibility ASC`, `createdAt DESC`
- `todos`: `date ASC`, `completed ASC`
- `publicFeed`: `visibility ASC`, `createdAt DESC`
