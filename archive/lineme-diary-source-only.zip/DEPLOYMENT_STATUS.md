# Deployment Status

Project: `bigdata-50693`

## Completed

- Firebase CLI installed locally in this project.
- Firebase login completed as `cloudpro31@iceu.kr`.
- `.firebaserc` configured for `bigdata-50693`.
- Firebase Web App config applied to `firebase-config.js`.
- Firestore Native database exists: `(default)`.
- Firestore rules deployed.
- Firestore indexes deployed.
- Firebase Hosting deployed.

Hosting URL:

```text
https://bigdata-50693.web.app
```

## Blocked By Console/Billing Setup

### Firebase Storage

Storage rule deploy failed because Firebase Storage has not been initialized.

Open:

```text
https://console.firebase.google.com/project/bigdata-50693/storage
```

Click `Get Started`, then choose the default bucket. After that run:

```powershell
npx.cmd firebase deploy --only storage --project bigdata-50693
```

### Cloud Functions / Vertex AI

Function deploy failed because the project is not on the Blaze pay-as-you-go plan.

Open:

```text
https://console.firebase.google.com/project/bigdata-50693/usage/details
```

Upgrade to Blaze. After that run:

```powershell
npx.cmd firebase deploy --only functions --project bigdata-50693
```

The function uses Vertex AI from the server side only. The browser app does not expose Vertex credentials.

### Firebase Authentication

Open:

```text
https://console.firebase.google.com/project/bigdata-50693/authentication/providers
```

Enable `Google` sign-in provider. Firebase Hosting domain `bigdata-50693.web.app` should be authorized automatically.
