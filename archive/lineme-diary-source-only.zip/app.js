const STORAGE_KEY = "bitduli-pwa-state";

const today = "2026-07-08";

const state = {
  screen: "splash",
  userName: "삐뚤이",
  color: "#FFE068",
  selectedDate: today,
  diary: {
    date: today,
    weather: "맑음",
    body: "오늘은 친구들과 카페에서 발표 준비를 했다.\n조금 떨렸지만 같이 이야기하면서 기분이 좋아졌다.\n내일 리허설 일정도 캘린더에 적어두었다."
  },
  friends: [
    { name: "지민이", color: "#BFD0FF" },
    { name: "도윤이", color: "#FFB5B8" },
    { name: "서아", color: "#E6D3FF" }
  ],
  entries: {
    "2026-07-01": { tone: "#FFF2AA", mood: "sunny" },
    "2026-07-02": { tone: "#E6D3FF", mood: "purple" },
    "2026-07-03": { tone: "#C7C9CE", mood: "gray" },
    "2026-07-04": { tone: "#FFF2AA", mood: "sunny" },
    "2026-07-05": { tone: "#BFD0FF", mood: "blue" },
    "2026-07-06": { tone: "#FFB5B8", mood: "red" },
    "2026-07-07": { tone: "#FFF2AA", mood: "sunny" },
    "2026-07-08": { tone: "#FFF2AA", mood: "sunny", note: "아." }
  }
};

function setScreen(screen) {
  state.screen = screen;
  saveState();
  render();
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({
    screen: state.screen,
    userName: state.userName,
    color: state.color,
    selectedDate: state.selectedDate,
    diary: state.diary
  }));
}

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
    Object.assign(state, saved);
  } catch {
    saveState();
  }
}

function statusBar() {
  return `
    <div class="status-bar" aria-hidden="true">
      <strong>9:41</strong>
      <span class="phone-icons"><i></i><i></i><i></i></span>
    </div>
  `;
}

function logo(size = "large") {
  return `
    <svg class="logo ${size}" viewBox="0 0 120 120" role="img" aria-label="삐뚤 캐릭터">
      <circle cx="60" cy="63" r="34" fill="#fff" stroke="currentColor" stroke-width="5"/>
      <path d="M43 53h1M75 53h1" stroke="currentColor" stroke-width="7" stroke-linecap="round"/>
      <path d="M43 74c12 14 34 13 44-2" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round"/>
      <path d="M42 31l-4-16M58 27V10M74 32l9-15" stroke="currentColor" stroke-width="5" stroke-linecap="round"/>
    </svg>
  `;
}

function icon(name) {
  const paths = {
    book: '<path d="M5 5h14a3 3 0 0 1 3 3v23H8a3 3 0 0 1-3-3V5Z"/><path d="M22 8h5a3 3 0 0 1 3 3v20H22"/>',
    pencil: '<path d="m7 25 2-7L23 4l5 5-14 14-7 2Z"/><path d="m20 7 5 5"/>',
    home: '<path d="M5 18 18 6l13 12"/><path d="M9 16v15h18V16"/>',
    users: '<circle cx="14" cy="13" r="5"/><path d="M5 31c1-7 17-7 18 0"/><path d="M23 13a4 4 0 1 0 0-8"/><path d="M25 31c5-2 7-7 2-11"/>',
    gear: '<circle cx="18" cy="18" r="5"/><path d="M18 3v5M18 28v5M3 18h5M28 18h5M7 7l4 4M25 25l4 4M29 7l-4 4M11 25l-4 4"/>',
    share: '<path d="M23 11 16 4l-7 7"/><path d="M16 5v22"/><path d="M6 20v10h20V20"/>',
    dots: '<circle cx="8" cy="18" r="2"/><circle cx="18" cy="18" r="2"/><circle cx="28" cy="18" r="2"/>',
    check: '<circle cx="18" cy="18" r="14"/><path d="m10 18 5 5 11-11"/>',
    x: '<circle cx="18" cy="18" r="14"/><path d="m13 13 10 10M23 13 13 23"/>',
    left: '<path d="m22 8-10 10 10 10"/>',
    right: '<path d="m14 8 10 10-10 10"/>'
  };
  return `<svg class="icon" viewBox="0 0 36 36" aria-hidden="true">${paths[name] || ""}</svg>`;
}

function frame(title, content, options = {}) {
  return `
    <main class="phone" data-screen="${state.screen}">
      ${statusBar()}
      <header class="app-header">
        ${options.logo ? logo("small") : "<span></span>"}
        <h1>${title}</h1>
        ${options.action || "<span></span>"}
      </header>
      <section class="screen-body">${content}</section>
      ${options.hideNav ? "" : tabBar()}
    </main>
  `;
}

function tabBar() {
  const tabs = [
    ["book", "book", "한달 그림책"],
    ["write", "pencil", "일기 작성"],
    ["calendar", "home", "달력"],
    ["friends", "users", "내 친구들"],
    ["settings", "gear", "설정"]
  ];
  return `
    <nav class="tab-bar" aria-label="주요 메뉴">
      ${tabs.map(([screen, iconName, label]) => `
        <button class="${state.screen === screen ? "active" : ""}" data-screen="${screen}" aria-label="${label}">
          ${icon(iconName)}
        </button>
      `).join("")}
    </nav>
  `;
}

function splashScreen() {
  return `<main class="splash" data-action="enter">${logo("splash")}</main>`;
}

function signupScreen() {
  return frame("", `
    <div class="auth-panel">
      ${logo("auth")}
      <h2>회원가입</h2>
      <label>Sign in with:</label>
      <button class="google-button" data-screen="profile"><span>G</span>Google</button>
    </div>
  `, { hideNav: true });
}

function profileScreen() {
  return frame("", `
    <div class="profile-setup">
      ${logo("auth")}
      <p>삐뚤에 온 것을 환영해요!</p>
      <label class="field">닉네임<input data-field="userName" value="${state.userName}" /></label>
      <div class="field">
        <span>프로필 색상</span>
        <div class="swatches">
          ${["#FFE068", "#BFD0FF", "#FFB5B8", "#C8F2C2", "#E6D3FF", "#757380", "#FFFFFF"].map((color) => `
            <button class="${state.color === color ? "selected" : ""}" style="--swatch:${color}" data-color="${color}" aria-label="${color}"></button>
          `).join("")}
          <button class="more-color" aria-label="더 많은 색상">${icon("dots")}</button>
        </div>
      </div>
      <button class="primary-button" data-screen="calendar">시작하기</button>
    </div>
  `, { hideNav: true });
}

function calendarScreen() {
  return frame("달력", `
    <div class="calendar-title">
      <div><strong>July</strong><span>2026</span><small>2026년 7월</small></div>
      <div class="month-controls"><button>${icon("left")}</button><b>오늘</b><button>${icon("right")}</button></div>
    </div>
    <div class="calendar-board">
      <div class="week-row">${["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day, index) => `<span class="${index === 0 ? "sun" : index === 6 ? "sat" : ""}">${day}</span>`).join("")}</div>
      <div class="month-grid">${calendarDays().map(dayCell).join("")}</div>
    </div>
  `, { logo: true });
}

function calendarDays() {
  const days = [];
  for (let day = 28; day <= 30; day += 1) days.push({ day, muted: true });
  for (let day = 1; day <= 31; day += 1) days.push({ day, date: `2026-07-${String(day).padStart(2, "0")}` });
  for (let day = 1; day <= 8; day += 1) days.push({ day, muted: true, next: true });
  return days;
}

function dayCell(item, index) {
  const entry = state.entries[item.date];
  const weekend = index % 7 === 0 ? "sun" : index % 7 === 6 ? "sat" : "";
  return `
    <button class="day-cell ${item.muted ? "muted" : ""} ${weekend} ${entry ? "has-entry" : ""}" data-date="${item.date || ""}">
      <span>${item.day}</span>
      ${entry ? `<div class="mood-card" style="--tone:${entry.tone}">${moodFace(entry.mood)}${entry.note ? `<small>${entry.note}</small>` : ""}</div>` : ""}
    </button>
  `;
}

function moodFace(mood = "sunny") {
  const fill = { purple: "#8A65AA", gray: "#6F7275", blue: "#6D7EBB", red: "#D35C5C" }[mood] || "#FFE068";
  return `
    <svg class="mood-face" viewBox="0 0 64 64" aria-hidden="true">
      <circle cx="32" cy="32" r="24" fill="${fill}" stroke="#171717" stroke-width="4"/>
      <path d="M18 15 14 5M31 10V2M45 15l6-9" stroke="#171717" stroke-width="4" stroke-linecap="round"/>
      <path d="M23 29h1M41 29h1" stroke="#171717" stroke-width="6" stroke-linecap="round"/>
      <path d="M22 42c7 7 18 7 25-1" fill="none" stroke="#171717" stroke-width="4" stroke-linecap="round"/>
    </svg>
  `;
}

function writeScreen() {
  return frame("일기 작성", `
    <form class="diary-form">
      <input data-diary="dateText" value="${formatKoreanDate(state.diary.date)}" aria-label="날짜" />
      <input data-diary="weather" value="날씨 : ${state.diary.weather}" aria-label="날씨" />
      <textarea data-diary="body" aria-label="일기 내용">${state.diary.body}</textarea>
      <button class="primary-button" type="button" data-action="save-diary">그림 일기 만들기</button>
    </form>
  `);
}

function diaryScreen() {
  return frame("오늘의 일기", `
    <div class="diary-page">${diaryArt()}</div>
  `, { action: `<button class="header-icon" data-screen="share" aria-label="공유">${icon("share")}</button>` });
}

function shareScreen() {
  return frame("오늘의 일기", `
    <div class="diary-page compact">${diaryArt()}</div>
    <div class="share-sheet">
      <h2>공유</h2>
      <button>내 친구들에게 공개</button>
      <button>사진으로 저장</button>
    </div>
  `, { action: `<button class="header-icon" data-screen="share" aria-label="공유">${icon("share")}</button>` });
}

function diaryArt() {
  const lines = state.diary.body.split("\n").slice(0, 3);
  return `
    <svg viewBox="0 0 395 531" role="img" aria-label="그림 일기">
      <rect width="395" height="531" rx="4" fill="#FFFDF5"/>
      <rect x="18" y="18" width="359" height="495" fill="#fff" stroke="#171717" stroke-width="4"/>
      <text x="34" y="52" font-size="19" font-weight="700">${formatKoreanDate(state.diary.date)}</text>
      <text x="245" y="52" font-size="17">날씨 : ${state.diary.weather}</text>
      <rect x="34" y="78" width="327" height="190" fill="#EAF8FF" stroke="#171717" stroke-width="4"/>
      <path d="M55 228c38-56 111-54 142 0M178 228c31-54 108-55 152 0" fill="none" stroke="#171717" stroke-width="5"/>
      <circle cx="128" cy="154" r="34" fill="${state.color}" stroke="#171717" stroke-width="5"/>
      <circle cx="264" cy="154" r="34" fill="#fff" stroke="#171717" stroke-width="5"/>
      <path d="M111 147h1M145 147h1M116 171c11 10 28 10 39-1M248 147h1M282 147h1M251 171c11 10 28 10 39-1" stroke="#171717" stroke-width="5" stroke-linecap="round"/>
      ${[302, 351, 400, 449].map((y) => `<path d="M34 ${y}h327" stroke="#DCDCDC" stroke-width="2"/>`).join("")}
      ${lines.map((line, index) => `<text x="48" y="${292 + index * 49}" font-size="20">${line}</text>`).join("")}
    </svg>
  `;
}

function friendsScreen() {
  return frame("내 친구들", `
    <div class="friends-list">
      ${state.friends.map((friend) => `
        <button class="friend-card" data-screen="friendCalendar">
          <span class="avatar" style="--avatar:${friend.color}">${logo("mini")}</span>
          <strong>${friend.name}</strong>
        </button>
      `).join("")}
    </div>
  `, { action: `<button class="header-icon" data-screen="friendSettings" aria-label="친구 설정">${icon("dots")}</button>` });
}

function friendCalendarScreen() {
  return frame("친구 1", `
    <div class="calendar-board friend-board">
      <div class="month-grid mini-calendar">${calendarDays().slice(3, 38).map(dayCell).join("")}</div>
    </div>
  `, { logo: true });
}

function friendSettingsScreen() {
  return frame("친구 설정", `
    <div class="settings-list friend-options">
      <button data-screen="friendInvite">친구 초대하기</button>
      <button data-screen="friendApprove">친구 승인하기</button>
      <button data-screen="friendDelete">친구 삭제하기</button>
    </div>
  `);
}

function friendInviteScreen() {
  return frame("친구 초대하기", `
    <form class="invite-form">
      <label class="field">이메일<input type="email" placeholder="friend@example.com" /></label>
      <button class="primary-button" type="button">초대하기</button>
    </form>
  `);
}

function friendActionScreen(title, mode) {
  return frame(title, `
    <div class="request-list">
      ${state.friends.map((friend) => `
        <article>
          <span class="avatar" style="--avatar:${friend.color}">${logo("mini")}</span>
          <strong>${friend.name}</strong>
          <div>
            ${mode === "approve" ? `<button aria-label="승인">${icon("check")}</button>` : ""}
            <button aria-label="삭제">${icon("x")}</button>
          </div>
        </article>
      `).join("")}
    </div>
  `);
}

function bookScreen() {
  return frame("한달 그림책", `
    <div class="book-list">
      ${["JAN", "FEB", "MAR", "APR", "MAY"].map((month, index) => `
        <button class="month-book ${index === 0 ? "featured" : ""}" data-screen="bookDetail">
          <span></span><strong>${month}</strong>
        </button>
      `).join("")}
    </div>
  `);
}

function bookDetailScreen() {
  return frame("한달 그림책", `
    <div class="book-detail">
      <div class="book-cover">
        <h2>July<br/>그림책</h2>
        ${moodFace("sunny")}
      </div>
      <div class="pager"><button>${icon("left")}</button><span>1 / 6</span><button>${icon("right")}</button></div>
    </div>
  `);
}

function settingsScreen() {
  return frame("설정", `
    <div class="profile-row"><strong>${state.userName}</strong><span>cloudpro3Z@iceu.kr</span></div>
    <div class="settings-list">
      ${["닉네임 설정", "친구 설정", "알림", "백업", "데이터 및 저장공간", "공지사항", "로그아웃", "회원탈퇴"].map((item) => `
        <button ${item === "친구 설정" ? 'data-screen="friendSettings"' : ""}>${item}</button>
      `).join("")}
    </div>
  `);
}

function formatKoreanDate(date) {
  return new Intl.DateTimeFormat("ko-KR", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    weekday: "short"
  }).format(new Date(`${date}T00:00:00`));
}

function render() {
  const screens = {
    splash: splashScreen,
    signup: signupScreen,
    profile: profileScreen,
    calendar: calendarScreen,
    write: writeScreen,
    diary: diaryScreen,
    share: shareScreen,
    friends: friendsScreen,
    friendCalendar: friendCalendarScreen,
    friendSettings: friendSettingsScreen,
    friendInvite: friendInviteScreen,
    friendApprove: () => friendActionScreen("친구 승인하기", "approve"),
    friendDelete: () => friendActionScreen("친구 삭제하기", "delete"),
    book: bookScreen,
    bookDetail: bookDetailScreen,
    settings: settingsScreen
  };
  document.querySelector("#app").innerHTML = (screens[state.screen] || calendarScreen)();
}

document.addEventListener("click", (event) => {
  const target = event.target.closest("[data-screen],[data-action],[data-color],[data-date]");
  if (!target) return;

  if (target.dataset.screen) setScreen(target.dataset.screen);
  if (target.dataset.action === "enter") setScreen("signup");
  if (target.dataset.action === "save-diary") setScreen("diary");
  if (target.dataset.color) {
    state.color = target.dataset.color;
    saveState();
    render();
  }
  if (target.dataset.date) {
    state.selectedDate = target.dataset.date;
    setScreen("diary");
  }
});

document.addEventListener("input", (event) => {
  const target = event.target;
  if (target.dataset.field === "userName") state.userName = target.value;
  if (target.dataset.diary === "weather") state.diary.weather = target.value.replace(/^날씨\s*:\s*/, "");
  if (target.dataset.diary === "body") state.diary.body = target.value;
  saveState();
});

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch(() => {});
  });
}

loadState();
render();
